# from crew_search_bot import CrewAgent

# agent = CrewAgent()
# agent.main('Andrew tate in 200 words')